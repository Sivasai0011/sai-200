/**
 * RoadVision AI - Main Application Controller
 * Three.js Scene Setup, Camera Controllers, Raycasting, Event Listeners, and Game Loop.
 */

class Application {
    constructor() {
        this.container = document.body;
        this.canvas = document.getElementById('three-canvas');

        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();

        // Components
        this.cityBuilder = null;
        this.vehicleManager = null;
        this.aiEngine = null;
        this.dashboard = null;

        // State
        this.isPaused = false;
        this.cameraMode = 'orbit'; // orbit, follow, drone
        this.followedVehicle = null;
        this.clock = new THREE.Clock();

        // Performance FPS counter
        this.frameCount = 0;
        this.lastFpsUpdate = performance.now();

        this.init();
    }

    init() {
        this.initThree();
        this.initComponents();
        this.initEventListeners();

        // Hide loading screen with GSAP fade
        setTimeout(() => {
            const loader = document.getElementById('loading-screen');
            if (loader && window.gsap) {
                gsap.to(loader, { opacity: 0, duration: 0.8, onComplete: () => loader.style.display = 'none' });
            } else if (loader) {
                loader.style.display = 'none';
            }
        }, 1200);

        this.animate();
    }

    initThree() {
        // 1. Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x06090e);
        this.scene.fog = new THREE.FogExp2(0x06090e, 0.003);

        // 2. Camera
        this.camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1, 1000);
        this.camera.position.set(120, 90, 160);

        // 3. Renderer
        this.renderer = new THREE.WebGLRenderer({
            canvas: this.canvas,
            antialias: true,
            powerPreference: 'high-performance'
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        // 4. Orbit Controls
        if (window.THREE.OrbitControls) {
            this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
            this.controls.enableDamping = true;
            this.controls.dampingFactor = 0.05;
            this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // Prevent going underground
            this.controls.target.set(0, 0, 0);
        }

        // 5. Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
        ambientLight.name = 'ambientLight';
        this.scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
        dirLight.name = 'dirLight';
        dirLight.position.set(100, 200, 100);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width = 2048;
        dirLight.shadow.mapSize.height = 2048;
        dirLight.shadow.camera.near = 10;
        dirLight.shadow.camera.far = 400;
        const d = 200;
        dirLight.shadow.camera.left = -d;
        dirLight.shadow.camera.right = d;
        dirLight.shadow.camera.top = d;
        dirLight.shadow.camera.bottom = -d;
        this.scene.add(dirLight);
    }

    initComponents() {
        this.cityBuilder = new CityBuilder(this.scene);
        this.cityBuilder.buildCityGrid();

        this.vehicleManager = new VehicleManager(this.scene);
        this.vehicleManager.spawnVehicles(24);

        this.aiEngine = new RoadVisionAI();

        this.dashboard = new DashboardController();
        this.dashboard.initCharts();
    }

    initEventListeners() {
        window.addEventListener('resize', () => this.onWindowResize());
        this.canvas.addEventListener('click', (e) => this.onCanvasClick(e));

        // Header Actions
        document.getElementById('btnWeatherToggle')?.addEventListener('click', () => {
            const modes = ['clear', 'rain', 'fog', 'snow', 'thunder'];
            const current = this.cityBuilder.weatherMode;
            const next = modes[(modes.indexOf(current) + 1) % modes.length];
            this.cityBuilder.setWeather(next);
            document.getElementById('valWeatherDisplay').textContent = next.toUpperCase();
            if (window.soundEngine) window.soundEngine.playClick();
        });

        document.getElementById('btnDayNightToggle')?.addEventListener('click', () => {
            const times = ['night', 'day', 'sunset'];
            const current = this.cityBuilder.timeOfDay;
            const next = times[(times.indexOf(current) + 1) % times.length];
            this.cityBuilder.setDayNight(next);
            if (window.soundEngine) window.soundEngine.playClick();
        });

        document.getElementById('btnVoiceToggle')?.addEventListener('click', (e) => {
            if (window.soundEngine) {
                const enabled = window.soundEngine.toggleVoice();
                e.currentTarget.classList.toggle('active', enabled);
                window.soundEngine.playClick();
            }
        });

        document.getElementById('btnEmergencyAlarm')?.addEventListener('click', () => {
            if (window.soundEngine) {
                window.soundEngine.playSiren();
                window.soundEngine.speak("Emergency Dispatch Alert! Emergency medical services and police deployed to Sector 2-3.");
            }
        });

        // Left Inspector Actions
        document.getElementById('btnFollowCar')?.addEventListener('click', () => {
            if (this.followedVehicle) {
                this.cameraMode = 'follow';
                if (window.soundEngine) window.soundEngine.playClick();
            } else {
                alert("Please select a vehicle first by clicking on it in 3D view.");
            }
        });

        document.getElementById('btnTriggerAnomaly')?.addEventListener('click', () => {
            if (this.followedVehicle) {
                this.followedVehicle.wrongWay = true;
                this.followedVehicle.direction.negate();
                this.followedVehicle.mesh.rotation.y += Math.PI;
                if (window.soundEngine) window.soundEngine.playAlert('high');
            }
        });

        document.getElementById('btnSearchVehicle')?.addEventListener('click', () => {
            const searchId = document.getElementById('inputSearchId').value.trim().toUpperCase();
            const found = this.vehicleManager.vehicles.find(v => v.id === searchId);
            if (found) {
                this.selectVehicle(found);
                this.cameraMode = 'follow';
            } else {
                alert("Vehicle ID not found in active traffic pool.");
            }
        });

        // Bottom Controls
        document.getElementById('btnPauseSim')?.addEventListener('click', (e) => {
            this.isPaused = !this.isPaused;
            e.currentTarget.classList.toggle('active', !this.isPaused);
            e.currentTarget.innerHTML = this.isPaused ? '<i class="fa-solid fa-play"></i> Resume' : '<i class="fa-solid fa-pause"></i> Pause';
        });

        document.getElementById('sliderDensity')?.addEventListener('input', (e) => {
            this.vehicleManager.setTrafficDensity(parseInt(e.target.value));
        });

        document.getElementById('sliderSpeed')?.addEventListener('input', (e) => {
            this.vehicleManager.baseSpeedMultiplier = parseFloat(e.target.value);
        });

        document.getElementById('btnToggleOverlays')?.addEventListener('click', (e) => {
            const enabled = !this.vehicleManager.overlaysEnabled;
            this.vehicleManager.toggleOverlays(enabled);
            e.currentTarget.classList.toggle('active', enabled);
        });

        document.getElementById('btnDroneMode')?.addEventListener('click', () => {
            this.cameraMode = 'drone';
            this.camera.position.set(0, 180, 1);
            if (this.controls) this.controls.target.set(0, 0, 0);
            if (window.soundEngine) window.soundEngine.playClick();
        });

        // Modals
        const analyticsModal = document.getElementById('modalAnalytics');
        document.getElementById('btnAnalyticsModal')?.addEventListener('click', () => {
            analyticsModal.classList.add('active');
        });
        document.getElementById('btnCloseAnalytics')?.addEventListener('click', () => {
            analyticsModal.classList.remove('active');
        });

        document.getElementById('btnExportPDF')?.addEventListener('click', () => {
            this.dashboard.exportPDFReport(this.aiEngine, this.vehicleManager);
        });
    }

    onCanvasClick(event) {
        this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.camera);
        const meshes = this.vehicleManager.vehicles.map(v => v.mesh);
        const intersects = this.raycaster.intersectObjects(meshes, true);

        if (intersects.length > 0) {
            // Find root vehicle object
            let root = intersects[0].object;
            while (root.parent && root.parent !== this.scene) {
                root = root.parent;
            }
            const foundVehicle = this.vehicleManager.vehicles.find(v => v.mesh === root);
            if (foundVehicle) {
                this.selectVehicle(foundVehicle);
                if (window.soundEngine) window.soundEngine.playScanSound();
            }
        }
    }

    selectVehicle(vehicle) {
        this.followedVehicle = vehicle;
        this.vehicleManager.selectedVehicle = vehicle;

        document.getElementById('inspectorVehicleId').textContent = vehicle.id;
        document.getElementById('statType').textContent = vehicle.type.toUpperCase();
        document.getElementById('statSpeed').textContent = Math.round(vehicle.speed * 3.6) + ' km/h';
        document.getElementById('statRisk').textContent = vehicle.riskScore + '%';
        document.getElementById('statRisk').style.color = vehicle.riskScore > 60 ? 'var(--neon-red)' : 'var(--neon-green)';
        document.getElementById('statBehavior').textContent = vehicle.predictedAnomaly || 'Nominal';
        document.getElementById('inspectorRecommendation').innerHTML = '<i class="fa-solid fa-robot"></i> ' + (vehicle.recommendation || 'Safe tracking parameters.');
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const delta = this.clock.getDelta();

        if (!this.isPaused) {
            this.cityBuilder.update(delta);
            this.vehicleManager.update(delta, this.cityBuilder);
            const stats = this.aiEngine.analyzeTrafficState(this.vehicleManager, this.cityBuilder.weatherMode, delta);

            this.dashboard.updateDashboardStats(stats);
            this.dashboard.updateHeatmap(this.vehicleManager.vehicles);
            this.dashboard.updateIncidentFeed(this.aiEngine.incidents);

            // Update selected vehicle live telemetry box if selected
            if (this.followedVehicle) {
                this.selectVehicle(this.followedVehicle);
            }
        }

        // Camera Modes Update
        if (this.cameraMode === 'follow' && this.followedVehicle) {
            const vPos = this.followedVehicle.mesh.position;
            const targetCamPos = new THREE.Vector3().copy(vPos).add(new THREE.Vector3(0, 15, -30));
            this.camera.position.lerp(targetCamPos, 0.1);
            if (this.controls) this.controls.target.lerp(vPos, 0.1);
        } else if (this.controls) {
            this.controls.update();
        }

        // Calculate FPS
        this.frameCount++;
        const now = performance.now();
        if (now - this.lastFpsUpdate >= 1000) {
            document.getElementById('valFps').textContent = Math.round((this.frameCount * 1000) / (now - this.lastFpsUpdate));
            this.frameCount = 0;
            this.lastFpsUpdate = now;
        }

        this.renderer.render(this.scene, this.camera);
    }
}

window.addEventListener('DOMContentLoaded', () => {
    window.app = new Application();
});
