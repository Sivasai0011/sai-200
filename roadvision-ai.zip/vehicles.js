/**
 * RoadVision AI - Vehicle & Simulation Engine (Three.js)
 * Manages vehicles, pedestrians, movement paths, and 3D overlays.
 */

class VehicleManager {
    constructor(scene) {
        this.scene = scene;
        this.vehicles = [];
        this.pedestrians = [];
        this.selectedVehicle = null;
        this.overlaysEnabled = true;
        this.baseSpeedMultiplier = 1.0;

        // Visual overlays group
        this.overlayGroup = new THREE.Group();
        this.scene.add(this.overlayGroup);
    }

    createVehicleMesh(type, colorHex) {
        const group = new THREE.Group();
        let bodyGeo, bodyMat;

        const mainColor = colorHex || (type === 'ambulance' ? 0xffffff : (type === 'bus' ? 0xffaa00 : Math.floor(Math.random() * 0xffffff)));
        bodyMat = new THREE.MeshStandardMaterial({
            color: mainColor,
            metalness: 0.8,
            roughness: 0.2
        });

        const glassMat = new THREE.MeshStandardMaterial({
            color: 0x05101a,
            roughness: 0.1,
            metalness: 0.9,
            transparent: true,
            opacity: 0.85
        });

        if (type === 'sedan' || type === 'sports') {
            // Main body
            bodyGeo = new THREE.BoxGeometry(2.2, 1.1, 4.4);
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.y = 0.75;
            body.castShadow = true;
            group.add(body);

            // Cabin
            const cabinGeo = new THREE.BoxGeometry(1.9, 0.8, 2.2);
            const cabin = new THREE.Mesh(cabinGeo, glassMat);
            cabin.position.set(0, 1.5, -0.3);
            group.add(cabin);
        } else if (type === 'suv') {
            bodyGeo = new THREE.BoxGeometry(2.4, 1.4, 4.8);
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.y = 0.9;
            body.castShadow = true;
            group.add(body);

            const cabinGeo = new THREE.BoxGeometry(2.2, 0.9, 3.2);
            const cabin = new THREE.Mesh(cabinGeo, glassMat);
            cabin.position.set(0, 1.85, -0.4);
            group.add(cabin);
        } else if (type === 'bus') {
            bodyGeo = new THREE.BoxGeometry(2.8, 2.8, 9.0);
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.y = 1.6;
            body.castShadow = true;
            group.add(body);
        } else if (type === 'ambulance') {
            bodyGeo = new THREE.BoxGeometry(2.6, 2.2, 5.5);
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.y = 1.3;
            body.castShadow = true;
            group.add(body);

            // Red Cross emblem
            const crossMat = new THREE.MeshBasicMaterial({ color: 0xff0044 });
            const crossH = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.4, 0.1), crossMat);
            crossH.position.set(1.31, 1.5, 0);
            crossH.rotation.y = Math.PI / 2;
            group.add(crossH);

            // Siren Lights
            const sirenMatRed = new THREE.MeshBasicMaterial({ color: 0xff0000 });
            const sirenMatBlue = new THREE.MeshBasicMaterial({ color: 0x0044ff });
            const sirenR = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.5), sirenMatRed);
            sirenR.position.set(-0.6, 2.55, 1.8);
            group.add(sirenR);
            const sirenB = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.5), sirenMatBlue);
            sirenB.position.set(0.6, 2.55, 1.8);
            group.add(sirenB);
        } else { // Truck
            bodyGeo = new THREE.BoxGeometry(2.8, 1.6, 3.0);
            const cabin = new THREE.Mesh(bodyGeo, bodyMat);
            cabin.position.set(0, 1.0, 2.5);
            group.add(cabin);

            const trailerGeo = new THREE.BoxGeometry(3.0, 3.0, 7.0);
            const trailerMat = new THREE.MeshStandardMaterial({ color: 0xd1d5db, roughness: 0.4 });
            const trailer = new THREE.Mesh(trailerGeo, trailerMat);
            trailer.position.set(0, 1.7, -2.2);
            trailer.castShadow = true;
            group.add(trailer);
        }

        // Wheels
        const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.4, 12);
        const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
        const wheelPositions = [
            [-1.1, 0.45, 1.4], [1.1, 0.45, 1.4],
            [-1.1, 0.45, -1.4], [1.1, 0.45, -1.4]
        ];
        wheelPositions.forEach(wp => {
            const wheel = new THREE.Mesh(wheelGeo, wheelMat);
            wheel.rotation.z = Math.PI / 2;
            wheel.position.set(wp[0], wp[1], wp[2]);
            group.add(wheel);
        });

        // Headlights (Neon glowing)
        const hlGeo = new THREE.BoxGeometry(0.4, 0.2, 0.1);
        const hlMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });
        const hlL = new THREE.Mesh(hlGeo, hlMat);
        hlL.position.set(-0.8, 0.7, 2.2);
        const hlR = new THREE.Mesh(hlGeo, hlMat);
        hlR.position.set(0.8, 0.7, 2.2);
        group.add(hlL);
        group.add(hlR);

        // 3D Bounding Box Overlay
        const bboxGeo = new THREE.BoxGeometry(3.2, 2.6, 5.8);
        const bboxMat = new THREE.MeshBasicMaterial({
            color: 0x00ff88,
            wireframe: true,
            transparent: true,
            opacity: 0.5
        });
        const bboxMesh = new THREE.Mesh(bboxGeo, bboxMat);
        bboxMesh.position.y = 1.3;
        bboxMesh.name = 'bboxOverlay';
        group.add(bboxMesh);

        // Trajectory Projection Line
        const trajGeo = new THREE.BufferGeometry();
        const trajPoints = new Float32Array(30 * 3);
        trajGeo.setAttribute('position', new THREE.BufferAttribute(trajPoints, 3));
        const trajMat = new THREE.LineDashedMaterial({
            color: 0x00ff88,
            dashSize: 1,
            gapSize: 0.5,
            linewidth: 2
        });
        const trajLine = new THREE.Line(trajGeo, trajMat);
        trajLine.name = 'trajLine';
        group.add(trajLine);

        return group;
    }

    spawnVehicles(count = 20) {
        // Clear existing
        this.vehicles.forEach(v => this.scene.remove(v.mesh));
        this.vehicles = [];

        const types = ['sedan', 'sports', 'suv', 'truck', 'bus', 'ambulance'];
        const lanes = [-168, -84, 0, 84, 168];

        for (let i = 0; i < count; i++) {
            const id = 'V-' + String(100 + i).padStart(3, '0');
            const type = (i === 0) ? 'ambulance' : types[Math.floor(Math.random() * types.length)];
            const mesh = this.createVehicleMesh(type);

            // Random lane alignment (East-West or North-South)
            const isHorizontal = Math.random() > 0.5;
            const laneOffset = (Math.random() > 0.5 ? 6 : -6);
            const roadCoord = lanes[Math.floor(Math.random() * lanes.length)];

            let x, z, dirX, dirZ;
            if (isHorizontal) {
                x = (Math.random() - 0.5) * 400;
                z = roadCoord + laneOffset;
                dirX = laneOffset > 0 ? 1 : -1;
                dirZ = 0;
                mesh.rotation.y = dirX > 0 ? Math.PI / 2 : -Math.PI / 2;
            } else {
                x = roadCoord + laneOffset;
                z = (Math.random() - 0.5) * 400;
                dirX = 0;
                dirZ = laneOffset > 0 ? 1 : -1;
                mesh.rotation.y = dirZ > 0 ? 0 : Math.PI;
            }

            mesh.position.set(x, 0, z);
            this.scene.add(mesh);

            const vehicle = {
                id,
                type,
                mesh,
                speed: 12 + Math.random() * 10, // mph / units
                targetSpeed: 15,
                direction: new THREE.Vector3(dirX, 0, dirZ).normalize(),
                lane: laneOffset,
                roadCoord,
                isHorizontal,
                riskScore: 0, // 0 - 100%
                predictedAnomaly: null,
                anomalyTimer: 0,
                braking: false,
                wrongWay: false,
                overspeed: false,
                laneDrifting: false,
                followingDistance: 15
            };

            this.vehicles.push(vehicle);
        }

        // Spawn Pedestrians
        this.spawnPedestrians(8);
    }

    spawnPedestrians(count = 8) {
        this.pedestrians.forEach(p => this.scene.remove(p.mesh));
        this.pedestrians = [];

        for (let i = 0; i < count; i++) {
            const pGroup = new THREE.Group();
            const bodyGeo = new THREE.CylinderGeometry(0.3, 0.3, 1.6, 8);
            const bodyMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.y = 0.8;
            pGroup.add(body);

            // Crosswalk position
            const x = (Math.random() - 0.5) * 200;
            const z = (Math.random() - 0.5) * 200;
            pGroup.position.set(x, 0, z);

            this.scene.add(pGroup);
            this.pedestrians.push({
                mesh: pGroup,
                direction: new THREE.Vector3(Math.random() - 0.5, 0, Math.random() - 0.5).normalize(),
                speed: 3
            });
        }
    }

    update(delta, cityBuilder) {
        const bounds = 240;

        // Update Vehicles
        this.vehicles.forEach((v, idx) => {
            // Apply speed & movement
            const effectiveSpeed = v.speed * this.baseSpeedMultiplier;
            v.mesh.position.addScaledVector(v.direction, effectiveSpeed * delta);

            // Wrap around boundary to keep continuous simulation
            if (Math.abs(v.mesh.position.x) > bounds) {
                v.mesh.position.x = -Math.sign(v.mesh.position.x) * (bounds - 10);
            }
            if (Math.abs(v.mesh.position.z) > bounds) {
                v.mesh.position.z = -Math.sign(v.mesh.position.z) * (bounds - 10);
            }

            // Check traffic signal at nearest intersection
            cityBuilder.trafficLights.forEach(tl => {
                const dist = v.mesh.position.distanceTo(tl.group.position);
                if (dist < 18 && tl.state === 'red' && !v.overspeed) {
                    // Slow down / stop at red light unless breaking traffic rules
                    v.speed = Math.max(0, v.speed - 25 * delta);
                } else if (dist < 25 && v.speed < v.targetSpeed) {
                    v.speed = Math.min(v.targetSpeed, v.speed + 15 * delta);
                }
            });

            // Update Trajectory Projected Lines
            const bbox = v.mesh.getObjectByName('bboxOverlay');
            const traj = v.mesh.getObjectByName('trajLine');

            if (bbox && traj) {
                // Color code based on risk severity score
                let colorHex = 0x00ff88; // Normal safe
                if (v.riskScore >= 70) {
                    colorHex = 0xff0055; // Danger High
                } else if (v.riskScore >= 40) {
                    colorHex = 0xffb700; // Warning Medium
                }

                bbox.material.color.setHex(colorHex);
                bbox.visible = this.overlaysEnabled;

                // Update trajectory line points
                const posArr = traj.geometry.attributes.position.array;
                for (let step = 0; step < 30; step++) {
                    const futureDist = step * 1.5;
                    posArr[step * 3] = v.direction.x * futureDist;
                    posArr[step * 3 + 1] = 0.2;
                    posArr[step * 3 + 2] = v.direction.z * futureDist;
                }
                traj.geometry.attributes.position.needsUpdate = true;
                traj.material.color.setHex(colorHex);
                traj.visible = this.overlaysEnabled;
            }
        });

        // Update Pedestrians
        this.pedestrians.forEach(p => {
            p.mesh.position.addScaledVector(p.direction, p.speed * delta);
            if (Math.abs(p.mesh.position.x) > bounds || Math.abs(p.mesh.position.z) > bounds) {
                p.direction.negate();
            }
        });
    }

    setTrafficDensity(count) {
        this.spawnVehicles(count);
    }

    toggleOverlays(enabled) {
        this.overlaysEnabled = enabled;
    }
}

window.VehicleManager = VehicleManager;
